#import <JavaScriptCore/JavaScriptCore.h>

void loadNFIKonyWebSocketsModules(JSContext* context);
JSValue* extractNFIKonyWebSocketsStructArgument(const char* type, NSInvocation* invocation, NSUInteger index, JSContext* context);
BOOL setNFIKonyWebSocketsStructReturnValue(const char* type, JSValue* value, NSInvocation* invocation);
