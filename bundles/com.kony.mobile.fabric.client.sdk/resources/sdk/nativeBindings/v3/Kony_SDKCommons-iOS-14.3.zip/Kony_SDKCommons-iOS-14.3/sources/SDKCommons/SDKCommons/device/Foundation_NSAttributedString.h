#import <JavaScriptCore/JavaScriptCore.h>
#import "allheaders.h"
#import "allprotos.h"
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
#pragma clang diagnostic ignored "-Wobjc-property-no-attribute"
#pragma clang diagnostic ignored "-Wnullability-completeness"
void load_Foundation_NSAttributedString_symbols(JSContext*);
@protocol NSAttributedStringInstanceExports<JSExport, NSCopyingInstanceExports_, NSMutableCopyingInstanceExports_, NSSecureCodingInstanceExports_>
@property (readonly,copy) NSString * string;
@end
@protocol NSAttributedStringClassExports<JSExport, NSCopyingClassExports_, NSMutableCopyingClassExports_, NSSecureCodingClassExports_>
@end
@protocol NSAttributedStringNSExtendedAttributedStringCategoryInstanceExports<JSExport>
@property (readonly) NSUInteger length;
-(NSAttributedString *) attributedSubstringFromRange: (NSRange) range ;
-(BOOL) isEqualToAttributedString: (NSAttributedString *) other ;
JSExportAs(initWithString,
-(id) jsinitWithString: (NSString *) str );
JSExportAs(initWithStringAttributes,
-(id) jsinitWithString: (NSString *) str attributes: (NSDictionary *) attrs );
JSExportAs(initWithAttributedString,
-(id) jsinitWithAttributedString: (NSAttributedString *) attrStr );
JSExportAs(enumerateAttributesInRangeOptionsUsingBlock,
-(void) jsenumerateAttributesInRange: (NSRange) enumerationRange options: (NSAttributedStringEnumerationOptions) opts usingBlock: (JSValue *) block );
JSExportAs(enumerateAttributeInRangeOptionsUsingBlock,
-(void) jsenumerateAttribute: (NSAttributedStringKey) attrName inRange: (NSRange) enumerationRange options: (NSAttributedStringEnumerationOptions) opts usingBlock: (JSValue *) block );
@end
@protocol NSAttributedStringNSExtendedAttributedStringCategoryClassExports<JSExport>
@end
@protocol NSMutableAttributedStringInstanceExports<JSExport>
-(void) replaceCharactersInRange: (NSRange) range withString: (NSString *) str ;
-(void) setAttributes: (NSDictionary *) attrs range: (NSRange) range ;
@end
@protocol NSMutableAttributedStringClassExports<JSExport>
@end
@protocol NSMutableAttributedStringNSExtendedMutableAttributedStringCategoryInstanceExports<JSExport>
@property (readonly,retain) NSMutableString * mutableString;
-(void) addAttribute: (NSAttributedStringKey) name value: (id) value range: (NSRange) range ;
-(void) addAttributes: (NSDictionary *) attrs range: (NSRange) range ;
-(void) removeAttribute: (NSAttributedStringKey) name range: (NSRange) range ;
-(void) replaceCharactersInRange: (NSRange) range withAttributedString: (NSAttributedString *) attrString ;
-(void) insertAttributedString: (NSAttributedString *) attrString atIndex: (NSUInteger) loc ;
-(void) appendAttributedString: (NSAttributedString *) attrString ;
-(void) deleteCharactersInRange: (NSRange) range ;
-(void) setAttributedString: (NSAttributedString *) attrString ;
-(void) beginEditing;
-(void) endEditing;
@end
@protocol NSMutableAttributedStringNSExtendedMutableAttributedStringCategoryClassExports<JSExport>
@end
#pragma clang diagnostic pop